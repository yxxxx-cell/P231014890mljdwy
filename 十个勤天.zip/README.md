# 十个勤天 - Web前端开发课程练习

本项目是一个基于 Next.js 的 Web 应用，以"十个勤天"为主题，展示"相信土地的力量"的农耕精神。应用集成了个人以往课程练习展示、WakaTime API 编码时长统计以及 QAnything 大语言模型问答服务。

## 项目主题

- **十个勤天**: 项目以《种地吧少年》节目中的"十个勤天"团队为主题，展示农耕生活和团队精神。
- **设计理念**: 采用绿色为主色调，象征生命、希望和农耕文化，整体设计简洁明了，突出"相信土地的力量"的核心理念。
- **用户体验**: 通过直观的导航和清晰的页面布局，为用户提供流畅的浏览体验。

## 项目特点

- **作品集展示**: 以独立的路由和组件化方式，整合展示本学期所有课程练习。
- **成员介绍**: 展示十个勤天团队成员的个人信息和简介。
- **精彩瞬间**: 展示团队在农耕过程中的精彩时刻和故事。
- **智能对话**: 通过 QAnything API 实现与十个勤天智能助手的对话交流。
- **WakaTime 集成**: 调用 WakaTime API，在页脚实时显示个人总编码时长，并使用环境变量安全管理 API Key。

## 技术栈

- [Next.js](https://nextjs.org/) – React 框架
- [React](https://reactjs.org/) – UI 库
- [TypeScript](https://www.typescriptlang.org/) – 类型化 JavaScript
- [Tailwind CSS](https://tailwindcss.com/) – CSS 框架
- [WakaTime API](https://wakatime.com/developers) – 编码活动跟踪
- [QAnything API](https://qanything.ai/) – 大语言模型服务

## 项目结构

```
/final-project
├── app/
│   ├── components/       # 共享组件 (如 Header, Footer)
│   ├── portfolio/        # 成员介绍页面
│   │   └── page.tsx
│   ├── qanything/        # 精彩瞬间和智能对话页面
│   │   └── page.tsx
│   ├── api/              # 后端 API 路由 (用于代理对外部API的请求)
│   │   ├── assignments/  # 作品集数据API
│   │   ├── qanything/    # QAnything API代理
│   │   └── wakatime/     # WakaTime API代理
│   ├── layout.tsx        # 全局布局
│   └── page.tsx          # 应用首页
├── public/               # 静态资源
│   ├── images/           # 图片资源
│   │   ├── background.jpg # 背景图片
│   │   └── 站位图.jpg     # 占位图片
│   └── assignments/      # 课程作业HTML文件
├── .env.local            # 环境变量 (存储 API Keys)
├── README.md             # 项目说明文件
└── ...                   # 其他 Next.js 配置文件
```

## QAnything 集成路径与实现

**选择路径**: 进阶路径 (Advanced Path)

**原因**:
选择进阶路径是为了更深入地挑战自我，全面实践前端开发的各项技能。通过自行设计和开发与 QAnything API 交互的前端界面，可以更好地掌握 API 对接、前端状态管理、异步操作、错误处理以及 UI/UX 设计。这不仅能满足作业的最高要求，也是一个将所学知识融会贯通的绝佳机会。

**实现细节**:
- **前端界面**: 在 `/app/qanything` 路径下，使用 React 和 Tailwind CSS 构建一个用户友好的聊天界面，包括输入框、发送按钮、以及展示问答历史的区域。
- **API 调用**: 将在后端 API 路由 (`/app/api/qanything`) 中处理对 QAnything API 的请求。这样做可以隐藏 API Key，避免其暴露在客户端，提高安全性。
- **状态管理**: 使用 React Hooks (如 `useState`, `useEffect`) 来管理用户输入、加载状态、API 返回的答案以及可能的错误信息。
- **高级特性**: 实现了基于URL参数的页面切换，用户可以在精彩瞬间和智能对话之间无缝切换。

## WakaTime API 集成方法

1.  从 [WakaTime Settings](https://wakatime.com/settings/api-key) 获取个人 API Key。
2.  将 API Key 存储在 `.env.local` 文件的 `WAKATIME_API_KEY` 变量中。
3.  创建一个服务器端函数或 API 路由，用于获取 WakaTime 数据，避免在客户端暴露 API Key。
4.  在全局 Footer 组件中调用该函数，获取并展示总编码时长。
5.  当API Key未配置或请求失败时，显示模拟数据，确保用户体验的连贯性。

## 本地开发指南

1.  **克隆仓库**
    ```bash
    git clone [你的仓库URL]
    cd final-project
    ```

2.  **安装依赖**
    ```bash
    npm install
    ```

3.  **设置环境变量**
    复制 `.env.example` (如果提供) 或手动创建 `.env.local` 文件，并填入您的 API 密钥：
    ```
    WAKATIME_API_KEY="YOUR_WAKATIME_API_KEY"
    QANYTHING_API_KEY="YOUR_QANYTHING_API_KEY"
    QANYTHING_AGENT_UUID="YOUR_QANYTHING_AGENT_UUID"
    ```

4.  **运行开发服务器**
    ```bash
    npm run dev
    ```

    在浏览器中打开 [http://localhost:3000](http://localhost:3000) 查看。

## 项目页面说明

### 1. 首页
首页展示了十个勤天的主题介绍和团队概述，以及三个主要功能区块的导航卡片。

### 2. 成员介绍
展示十个勤天团队成员的个人信息、角色和简介，让用户了解团队的组成。

### 3. 精彩瞬间
展示团队在农耕过程中的精彩时刻，同时集成了课程作业的展示功能。

### 4. 智能对话
通过QAnything API实现与十个勤天智能助手的对话交流，用户可以询问关于团队的问题。

## 运行截图

*待项目完成后，在此处嵌入截图。*

### 1. 首页截图
![首页截图](https://via.placeholder.com/600x400.png?text=十个勤天首页截图)

### 2. 成员介绍截图
![成员介绍截图](https://via.placeholder.com/600x400.png?text=成员介绍截图)

### 3. 精彩瞬间截图
![精彩瞬间截图](https://via.placeholder.com/600x400.png?text=精彩瞬间截图)

### 4. 智能对话截图
![智能对话截图](https://via.placeholder.com/600x400.png?text=智能对话截图)

## GitHub 仓库管理

本项目所有代码和文档均通过 Git 进行版本控制，并托管在公共 GitHub 仓库中。Commit 信息遵循清晰、有意义的原则，以保持良好的开发历史记录。
