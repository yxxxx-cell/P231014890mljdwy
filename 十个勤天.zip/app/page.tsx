import Image from "next/image";
import Link from "next/link";

export default function Home() {
  return (
    <div className="flex flex-col items-center">
      <div className="text-center mb-10">
        <h1 className="text-4xl sm:text-5xl font-bold mb-6 text-green-theme">
          《 种 地 吧 少 年 》
        </h1>
        <div className="flex justify-center mb-8">
          <Image 
            src="/images/站位图.jpg" 
            alt="十个勤天团队" 
            width={600} 
            height={400} 
            className="rounded-lg shadow-lg"
          />
        </div>
        <p className="text-lg max-w-3xl mx-auto mb-8">
          种地吧少年！不负春光，健康生长 ✨ |||||||||。
          《种地吧第一季》更实于中国农村的青年情况，但仅仅142.8亩，用八块农田、一条河道、三个鱼塘、两栋旧房子和一个仓库组成一个微型农场。节目选取10位年轻人组成"种地小队"，真实记录他们在142.8亩土地上，在190天时间里，播种、灌溉、施肥、收获，最终运营农场。
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 w-full max-w-5xl">
        <Link href="/portfolio">
          <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow">
            <div className="h-48 relative">
              <Image 
                src="/images/站位图.jpg" 
                alt="成员介绍" 
                fill 
                style={{objectFit: 'cover'}} 
              />
            </div>
            <div className="p-4 bg-green-theme text-white text-center">
              <h2 className="text-xl font-bold">成员介绍</h2>
            </div>
          </div>
        </Link>

        <Link href="/qanything">
          <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow">
            <div className="h-48 relative">
              <Image 
                src="/images/站位图.jpg" 
                alt="精彩瞬间" 
                fill 
                style={{objectFit: 'cover'}} 
              />
            </div>
            <div className="p-4 bg-green-theme text-white text-center">
              <h2 className="text-xl font-bold">精彩瞬间</h2>
            </div>
          </div>
        </Link>

        <Link href="/qanything?chat=true">
          <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-xl transition-shadow">
            <div className="h-48 relative">
              <Image 
                src="/images/站位图.jpg" 
                alt="和我们对话" 
                fill 
                style={{objectFit: 'cover'}} 
              />
            </div>
            <div className="p-4 bg-green-theme text-white text-center">
              <h2 className="text-xl font-bold">和我们对话</h2>
            </div>
          </div>
        </Link>
      </div>
    </div>
  );
}
