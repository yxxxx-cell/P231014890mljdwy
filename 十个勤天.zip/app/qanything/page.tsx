'use client';

import { useState, useRef, useEffect, useLayoutEffect } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';

// 定义消息源信息的接口
interface Source {
  fileId: string;
  fileName: string;
  content: string;
  score: string;
}

// 定义聊天消息的角色和内容
interface Message {
  role: 'user' | 'assistant';
  content: string;
  thinkContent?: string; // 可选的思考过程内容
  sources?: Source[]; // 可选的消息源信息
}

// 定义作品类型
type Assignment = {
  filename: string;
  name: string;
  path: string;
};

// 辅助函数，用于将文件名转换为更易读的标题
function formatAssignmentName(filename: string): string {
  return filename
    .replace('.html', '') // 移除扩展名
    .replace(/[-_]/g, ' ') // 将连字符和下划线替换为空格
    .replace(/\b\w/g, (char) => char.toUpperCase()); // 将每个单词的首字母大写
}

/**
 * 处理API返回的消息内容，提取<response>标签中的内容
 */
function processApiResponse(text: string): string {
  // 如果包含<response>标签，则只显示<response>标签内的内容
  if (text.includes('<response>')) {
    const responseMatch = text.match(/<response>([\s\S]*?)<\/response>/);
    if (responseMatch && responseMatch[1]) {
      return responseMatch[1].trim();
    }
  }
  
  // 如果包含<think>标签但没有<response>标签，则过滤掉<think>标签内容
  if (text.includes('<think>')) {
    return text.replace(/<think>[\s\S]*?<\/think>/g, '').trim();
  }
  
  // 如果没有任何标签，则返回原始文本
  return text;
}

/**
 * 加载动画组件
 */
function LoadingIndicator() {
  return (
    <div className="flex justify-center items-center py-2">
      <div className="flex space-x-1">
        <div className="w-2 h-2 bg-green-theme rounded-full animate-bounce" style={{ animationDelay: '0s' }}></div>
        <div className="w-2 h-2 bg-green-theme rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
        <div className="w-2 h-2 bg-green-theme rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
      </div>
    </div>
  );
}

/**
 * 消息源信息组件
 */
function SourceInfo({ sources }: { sources: Source[] }) {
  const [isExpanded, setIsExpanded] = useState(false);
  
  if (!sources || sources.length === 0) return null;
  
  return (
    <div className="mt-2 text-xs">
      <button 
        onClick={() => setIsExpanded(!isExpanded)} 
        className="text-green-theme hover:underline flex items-center"
      >
        <span>{isExpanded ? '隐藏来源' : '查看来源'}</span>
        <svg 
          className={`w-4 h-4 ml-1 transform ${isExpanded ? 'rotate-180' : ''}`} 
          fill="none" 
          stroke="currentColor" 
          viewBox="0 0 24 24" 
          xmlns="http://www.w3.org/2000/svg"
        >
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
        </svg>
      </button>
      
      {isExpanded && (
        <div className="mt-2 p-2 bg-gray-100 rounded-md">
          {sources.map((source, index) => (
            <div key={index} className="mb-2 pb-2 border-b border-gray-200 last:border-b-0">
              <div className="font-semibold">文件: {source.fileName}</div>
              <div className="mt-1 text-gray-600 whitespace-pre-wrap">{source.content}</div>
              <div className="mt-1 text-gray-500">相关度: {parseFloat(source.score).toFixed(2)}</div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export default function QAnythingPage() {
  // 获取URL参数
  const searchParams = useSearchParams();
  const showChat = searchParams.get('chat') === 'true';
  
  // 保留原有的状态和引用
  const [question, setQuestion] = useState('');
  const [messages, setMessages] = useState<Message[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  
  // 作品集数据
  const [assignments, setAssignments] = useState<Assignment[]>([]);

  useEffect(() => {
    // 获取作品集数据
    async function fetchAssignments() {
      try {
        const response = await fetch('/api/assignments');
        if (response.ok) {
          const data = await response.json();
          setAssignments(data);
        }
      } catch (error) {
        console.error('获取作品集失败:', error);
      }
    }
    
    fetchAssignments();
  }, []);

  useLayoutEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // 保留原有的提交处理函数
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!question.trim() || isLoading) return;

    const userMessage: Message = { role: 'user', content: question };
    
    const historyMessages = messages.reduce((acc: { question: string; response: string }[], msg, index) => {
      if (msg.role === 'user' && messages[index + 1]?.role === 'assistant') {
        acc.push({ question: msg.content, response: messages[index + 1].content });
      }
      return acc;
    }, []);

    const assistantPlaceholder: Message = { role: 'assistant', content: '', thinkContent: '' };
    setMessages([...messages, userMessage, assistantPlaceholder]);
    setQuestion('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/qanything', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          question: question,
          history: historyMessages.slice(-2),
        }),
      });

      if (!res.ok || !res.body) {
        throw new Error('API request failed');
      }

      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = '';
      let fullResponseText = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;

        buffer += decoder.decode(value, { stream: true });
        
        let newlineIndex;
        while ((newlineIndex = buffer.indexOf('\n')) !== -1) {
          const line = buffer.slice(0, newlineIndex).trim();
          buffer = buffer.slice(newlineIndex + 1);

          if (line.startsWith('data:')) {
            const jsonStr = line.substring(5).trim();
            if (jsonStr) {
              try {
                const parsed = JSON.parse(jsonStr);
                
                if (parsed.result?.response) {
                  fullResponseText += parsed.result.response;
                }
                
                const sources = parsed.result?.source;

                const thinkMatch = fullResponseText.match(/<think>([\s\S]*?)<\/think>/);
                const responseMatch = fullResponseText.match(/<response>([\s\S]*?)<\/response>/);

                const thinkContent = thinkMatch ? thinkMatch[1].trim() : '';
                let content = '';

                if (responseMatch) {
                  content = responseMatch[1].trim();
                } else {
                  content = fullResponseText.replace(/<think>[\s\S]*?<\/think>/, '').trim();
                }

                setMessages(prevMessages => {
                  const newMessages = [...prevMessages];
                  const lastMessage = newMessages[newMessages.length - 1];
                  if (lastMessage && lastMessage.role === 'assistant') {
                    lastMessage.content = content;
                    lastMessage.thinkContent = thinkContent;
                    lastMessage.sources = sources;
                  }
                  return newMessages;
                });

              } catch (e) {
                console.error("无法解析收到的JSON:", jsonStr, e);
              }
            }
          }
        }
      }
    } catch (error: any) {
      console.error('Fetch error:', error);
      setMessages(prev => {
        const newMessages = [...prev];
        const lastMessage = newMessages[newMessages.length - 1];
        if (lastMessage && lastMessage.role === 'assistant') {
          lastMessage.content = `抱歉，请求出错了：\n${error.message}`;
        }
        return newMessages;
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <h1 className="text-3xl sm:text-4xl font-bold mb-6 text-center text-green-theme">
        {showChat ? "和我们对话" : "精彩瞬间"}
      </h1>
      
      {/* 作品集展示区 */}
      {!showChat && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[
            { filename: "03-css-01.html", name: "CSS基础练习1" },
            { filename: "03-css-02.html", name: "CSS基础练习2" },
            { filename: "04-css-01.html", name: "CSS布局练习1" },
            { filename: "04-css-02.html", name: "CSS布局练习2" },
            { filename: "05-news-01.html", name: "新闻网站1" },
            { filename: "05-news-02.html", name: "新闻网站2" },
            { filename: "06-news-01.html", name: "响应式新闻1" },
            { filename: "06-news02.html", name: "响应式新闻2" },
            { filename: "07-async-01.html", name: "异步编程1" },
            { filename: "07-async-02.html", name: "异步编程2" }
          ].map((assignment) => (
            <Link key={assignment.filename} href={`/assignments/${assignment.filename}`} target="_blank">
              <div className="block p-6 bg-white rounded-lg shadow-lg hover:shadow-xl transition-colors duration-200 h-full">
                <h2 className="text-xl font-semibold text-green-theme mb-2">{assignment.name}</h2>
                <p className="text-gray-600">点击查看详情</p>
              </div>
            </Link>
          ))}
        </div>
      )}
      
      {/* 如果不是通过URL参数直接访问聊天界面，则显示切换按钮 */}
      {!showChat && (
        <div className="flex justify-center mt-8">
          <Link href="/qanything?chat=true" className="btn-green">
            与十个勤天智能助手交流
          </Link>
        </div>
      )}
      
      {/* 聊天区域 */}
      {showChat && (
        <div className="bg-white rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-bold mb-4 text-green-theme">十个勤天智能助手</h2>
          <div className="h-[400px] flex flex-col">
            <div className="flex-1 overflow-y-auto space-y-4 p-4 bg-gray-50 rounded-lg mb-4">
              {messages.length === 0 ? (
                <div className="flex justify-center items-center h-full text-gray-500">
                  <p>您好！请输入您的问题，我将尽力回答关于"十个勤天"的问题。</p>
                </div>
              ) : (
                <>
                  {messages.map((msg, index) => (
                    <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div
                        className={`max-w-xs md:max-w-md lg:max-w-lg px-4 py-2 rounded-lg whitespace-pre-wrap ${
                          msg.role === 'user' ? 'bg-green-theme text-white' : 'bg-gray-200 text-gray-800'
                        }`}
                      >
                        {msg.thinkContent && (
                          <div className="mb-2 p-2 bg-gray-100 text-gray-600 rounded-md text-sm">
                            <h4 className="font-semibold text-gray-700">思考过程...</h4>
                            <p>{msg.thinkContent}</p>
                          </div>
                        )}
                        
                        {msg.content}
                        
                        {msg.role === 'assistant' && msg.sources && <SourceInfo sources={msg.sources} />}
                      </div>
                    </div>
                  ))}
                  <div ref={messagesEndRef}></div>
                </>
              )}
              {isLoading && <LoadingIndicator />}
            </div>

            <form onSubmit={handleSubmit} className="flex">
              <input
                type="text"
                value={question}
                onChange={(e) => setQuestion(e.target.value)}
                placeholder="请输入您的问题..."
                className="flex-1 p-2 border border-gray-300 rounded-l-md focus:outline-none focus:ring-2 focus:ring-green-theme"
                disabled={isLoading}
              />
              <button
                type="submit"
                className="bg-green-theme text-white px-4 py-2 rounded-r-md hover:bg-dark-green transition-colors"
                disabled={isLoading}
              >
                发送
              </button>
            </form>
          </div>
          
          <div className="mt-4 text-center">
            <Link href="/qanything" className="text-green-theme hover:underline">
              返回精彩瞬间
            </Link>
          </div>
        </div>
      )}
    </div>
  );
} 