import { NextResponse } from 'next/server';
import fs from 'fs';
import path from 'path';

export async function GET() {
  try {
    const assignmentsDirectory = path.join(process.cwd(), 'public', 'assignments');
    const filenames = fs.readdirSync(assignmentsDirectory);
    
    const assignments = filenames
      .filter((file) => file.endsWith('.html'))
      .map((filename) => {
        // 将文件名转换为更易读的标题
        const name = filename
          .replace('.html', '')
          .replace(/[-_]/g, ' ')
          .replace(/\b\w/g, (char) => char.toUpperCase());
          
        return {
          filename,
          name,
          path: `/assignments/${filename}`
        };
      });
      
    return NextResponse.json(assignments);
  } catch (error) {
    console.error('无法读取作品集目录:', error);
    return NextResponse.json(
      { error: '无法读取作品集目录' },
      { status: 500 }
    );
  }
} 