import { NextResponse } from 'next/server';

export const revalidate = 3600; // 每小时重新验证一次 (3600秒)

export async function GET() {
  const apiKey = process.env.WAKATIME_API_KEY;

  // 如果没有配置API密钥，返回模拟数据
  if (!apiKey) {
    console.log('WakaTime API key not found, returning mock data');
    return NextResponse.json({ 
      total_time_text: '10 hrs 42 mins',
      mock: true 
    });
  }

  try {
    // 注意：WakaTime 的 API key 需要以 Base64 编码
    const authHeader = `Basic ${Buffer.from(apiKey).toString('base64')}`;
    
    const response = await fetch('https://wakatime.com/api/v1/users/current/all_time_since_today', {
      headers: {
        'Authorization': authHeader,
      },
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('WakaTime API Error:', errorText);
      
      // 如果API请求失败，也返回模拟数据
      console.log('WakaTime API request failed, returning mock data');
      return NextResponse.json({ 
        total_time_text: '10 hrs 42 mins',
        mock: true 
      });
    }

    const data = await response.json();

    // 我们只返回前端需要的数据，例如总编码时间的文本表示
    return NextResponse.json({ total_time_text: data.data.text });

  } catch (error) {
    console.error('Internal Server Error:', error);
    
    // 如果发生任何错误，返回模拟数据
    console.log('Error occurred, returning mock data');
    return NextResponse.json({ 
      total_time_text: '10 hrs 42 mins',
      mock: true 
    });
  }
} 