import Image from 'next/image';

// 成员信息
const members = [
  {
    id: 1,
    name: '蒋敦豪',
    nickname: '豆叔',
    role: '队长',
    description: '1995年5月21日出生于新疆博尔塔拉蒙古自治州博乐市，中国内地男歌手，毕业于新疆艺术学院音乐系。2015年，蒋敦豪和朋友们成立了"漫山音乐工作室"；5月，推出个人电影推广曲《2015》；2016年，参加浙江卫视歌唱类节目《中国新歌声》的比赛，终获得蒙面唱将冠军、全国总决赛亚军；2018年，推出首张个人音乐专辑《少年心事》；2019年，参加优酷综艺节目《一起乐队吧》；与四位音乐人在节目中组成乐队"九连真人"。',
    image: '/images/站位图.jpg'
  },
  {
    id: 2,
    name: '鹭卓',
    nickname: '鹭卓',
    role: '成员',
    description: '"十个勤天"成员之一，参与《种地吧少年》节目的录制，与团队一起在农田中辛勤耕作，体验农耕生活。',
    image: '/images/站位图.jpg'
  },
  {
    id: 3,
    name: '李耕耘',
    nickname: '耕耘',
    role: '成员',
    description: '"十个勤天"成员之一，参与《种地吧少年》节目的录制，与团队一起在农田中辛勤耕作，体验农耕生活。',
    image: '/images/站位图.jpg'
  },
  {
    id: 4,
    name: '李昊',
    nickname: '星星',
    role: '副队长',
    description: '1995年出生于山东，毕业于中央戏剧学院表演系。曾参演电视剧《最美的青春》《我们的西南联大》《平凡的荣耀》《风起洛阳》等。2022年，主演的电视剧《星落凝成糖》播出。',
    image: '/images/站位图.jpg'
  },
  {
    id: 5,
    name: '赵一博',
    nickname: '一博',
    role: '成员',
    description: '"十个勤天"成员之一，参与《种地吧少年》节目的录制，与团队一起在农田中辛勤耕作，体验农耕生活。',
    image: '/images/站位图.jpg'
  },
  {
    id: 6,
    name: '卓沅',
    nickname: '卓沅',
    role: '成员',
    description: '"十个勤天"成员之一，参与《种地吧少年》节目的录制，与团队一起在农田中辛勤耕作，体验农耕生活。',
    image: '/images/站位图.jpg'
  },
  {
    id: 7,
    name: '赵小童',
    nickname: '小童',
    role: '成员',
    description: '"十个勤天"成员之一，参与《种地吧少年》节目的录制，与团队一起在农田中辛勤耕作，体验农耕生活。',
    image: '/images/站位图.jpg'
  },
  {
    id: 8,
    name: '何浩楠',
    nickname: '浩楠',
    role: '成员',
    description: '"十个勤天"成员之一，参与《种地吧少年》节目的录制，与团队一起在农田中辛勤耕作，体验农耕生活。',
    image: '/images/站位图.jpg'
  },
  {
    id: 9,
    name: '陈少熙',
    nickname: '少熙',
    role: '成员',
    description: '"十个勤天"成员之一，参与《种地吧少年》节目的录制，与团队一起在农田中辛勤耕作，体验农耕生活。',
    image: '/images/站位图.jpg'
  },
  {
    id: 10,
    name: '王一珩',
    nickname: '一珩',
    role: '成员',
    description: '"十个勤天"成员之一，参与《种地吧少年》节目的录制，与团队一起在农田中辛勤耕作，体验农耕生活。',
    image: '/images/站位图.jpg'
  }
];

export default function MembersPage() {
  return (
    <div>
      <h1 className="text-3xl sm:text-4xl font-bold mb-6 text-center text-green-theme">• 十个勤天 •</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-8">
        {members.map((member) => (
          <div key={member.id} className="bg-white rounded-lg shadow-lg overflow-hidden">
            <div className="md:flex">
              <div className="md:w-1/3">
                <div className="h-64 md:h-full relative">
                  <Image 
                    src={member.image} 
                    alt={member.name} 
                    fill 
                    style={{objectFit: 'cover'}}
                  />
                </div>
              </div>
              <div className="md:w-2/3 p-6">
                <div className="flex items-center mb-2">
                  <h2 className="text-xl font-bold text-green-theme">{member.name}</h2>
                  <span className="ml-2 px-2 py-1 bg-green-theme text-white text-xs rounded-full">{member.role}</span>
                  <span className="ml-2 text-gray-500">({member.nickname})</span>
                </div>
                <p className="text-gray-700 text-sm">{member.description}</p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
} 