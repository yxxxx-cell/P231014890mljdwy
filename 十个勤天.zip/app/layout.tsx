import type { Metadata } from "next";
import { Inter } from "next/font/google";
import "./globals.css";
import Header from "./components/Header";
import Footer from "./components/Footer";

const inter = Inter({ subsets: ["latin"] });

export const metadata: Metadata = {
  title: "十个勤天 - Web前端开发课程练习",
  description: "相信土地的力量 - 用代码构建视觉，以前端连接世界",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="zh-CN">
      <body className={`${inter.className} flex flex-col min-h-screen`}>
        <div className="banner">
          <div className="banner-text">种地吧十个勤天—— "相信土地的力量"</div>
        </div>
        <Header />
        <main className="flex-grow bg-image">
          <div className="container-custom bg-overlay py-8 min-h-full">
            {children}
          </div>
        </main>
        <Footer />
      </body>
    </html>
  );
}
