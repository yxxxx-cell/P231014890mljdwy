import Link from 'next/link';
import Image from 'next/image';

export default function Header() {
  return (
    <header className="bg-green-theme shadow-md">
      <nav className="container-custom flex justify-between items-center py-3">
        <div className="flex items-center space-x-2">
          <Link href="/" className="flex items-center text-xl font-bold text-white hover:text-light-green transition-colors">
            <Image 
              src="/images/站位图.jpg" 
              alt="十个勤天Logo" 
              width={40} 
              height={40} 
              className="rounded-full mr-2"
            />
            <span>十个勤天</span>
          </Link>
        </div>
        <div className="flex space-x-1">
          <Link href="/" className="nav-link">
            首页
          </Link>
          <Link href="/portfolio" className="nav-link">
            成员介绍
          </Link>
          <Link href="/qanything" className="nav-link">
            精彩瞬间
          </Link>
          <Link href="/qanything?chat=true" className="nav-link">
            和我们对话
          </Link>
        </div>
      </nav>
    </header>
  );
} 